This is my second approach that uses Neural Networks with multiple hidden layers


Approach:
1. Acknowledged all entries that were factors(e.g. in Gender Column, Hometown Column, etc.), and 
changed their values to 'numerics' so we can use values in our linear model.

2. Missing 'cells' or entries I filled with mean of the columns. I might try the median approach,
but time will tell.

3. Finally, I used the neural network to predict the values from the test data.  

4. Since there are nuances with neural networks, I will keep working on this model until I have a somewhat ideal output, after tuning the neural nets parameters.