This first approach is the 'bread and butter' of ml:
1. Linear Regression

I understand Linear Regression more than other ML models, as such
I had to implement the algorithm in this ML challenge.

Approach:
1. Acknowledged all entries that were factors(e.g. in Gender Column, Hometown Column, etc.), and 
changed their values to 'numerics' so we can use values in our linear model.

2. Missing 'cells' or entries I filled with mean of the columns. I might try the median approach,
but time will tell.

3. Finally, I used the linear regression model to predict the values from the test data.  